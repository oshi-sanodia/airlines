import { ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ActivatedRoute } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { EditPassengerComponent } from './edit-passenger.component';
import { CommonService } from 'src/app/shared/service/common.service';
import { of } from 'rxjs';

describe('EditPassengerComponent', () => {
  let component: EditPassengerComponent;
  let fixture: ComponentFixture<EditPassengerComponent>;
  let route: ActivatedRoute;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EditPassengerComponent ],
      imports: [HttpClientTestingModule, RouterTestingModule, FormsModule, ReactiveFormsModule],
      providers: [CommonService]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EditPassengerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    component.updatePassenger.patchValue({id:0});
    component.updatePassenger.patchValue({name:'test'});
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call  getPassengerDetails() method', () => {
    const mock=[{id:0}]
    spyOn(component, 'getPassengerDetails').and.callThrough();
    spyOn(CommonService.prototype, 'getPassengerDetails').and.returnValue(of(mock as any))
    component.getPassengerDetails();
    fixture.detectChanges();
    expect(component.getPassengerDetails).toHaveBeenCalled();
  });

  it('should call  getIndex() method', () => {
    const pId=0;
    spyOn(component, 'getIndex').and.callThrough();
    component.getIndex(pId);
    fixture.detectChanges();
    expect(component.getIndex).toHaveBeenCalled();
  });

  it('should call  editPassenger() method', () => {
    component.index=0
    component.passengerDetails=[{name:'test'}]
    component.updatePassenger.patchValue({id:0});
    component.updatePassenger.patchValue({name:'test'});
    component.passengerDetails=[{passport:{provided:true},address:{provided:true},dob:{provided:true} }]
    spyOn(component, 'editPassenger').and.callThrough();
    component.editPassenger();
    fixture.detectChanges();
    expect(component.editPassenger).toHaveBeenCalled();
  });


});
