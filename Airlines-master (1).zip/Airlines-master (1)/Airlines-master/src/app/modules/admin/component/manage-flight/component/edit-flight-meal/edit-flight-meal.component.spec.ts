import { ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ActivatedRoute } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { EditFlightMealComponent } from './edit-flight-meal.component';
import { CommonService } from 'src/app/shared/service/common.service';
import { of } from 'rxjs';

describe('EditFlightMealComponent', () => {
  let component: EditFlightMealComponent;
  let fixture: ComponentFixture<EditFlightMealComponent>;
  let route: ActivatedRoute;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EditFlightMealComponent ],
      imports: [HttpClientTestingModule, RouterTestingModule],
      providers: [CommonService]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EditFlightMealComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    component.updateMeal.patchValue({mealName:'test',price:0})
  });

  it('should call  getFlightDetails() method', () => {
    component.index=0
    component.mealIndex=0
    component.flightDetails=[{ancillary:{meal:[{mealName:'test',price:0}]}}]
    const mock=[{id:0}]
    spyOn(component, 'getFlightDetails').and.callThrough();
   // spyOn(CommonService.prototype, 'getFlightDetails').and.returnValue(of(mock as any))
    component.getFlightDetails();
    fixture.detectChanges();
    expect(component.getFlightDetails).toHaveBeenCalled();
  });

  it('should call  getIndex() method', () => {
    const fId=0;
    component.index=0
    component.mealIndex=0
    component.flightDetails=[{ancillary:{meal:[{mealName:'test',price:0}]}}]
    spyOn(component, 'getIndex').and.callThrough();
    component.getIndex(fId);
    fixture.detectChanges();
    expect(component.getIndex).toHaveBeenCalled();
  });

  // it('should call  updatePassengerDetail() method', () => {
  //   const id=0;
  //   spyOn(component, 'updatePassengerDetail').and.callThrough();
  //   component.updatePassengerDetail(id);
  //   fixture.detectChanges();
  //   expect(component.updatePassengerDetail).toHaveBeenCalled();
  // });

  it('should call  editMeal() method', () => {
    component.index=0
    component.mealIndex=0
    component.flightDetails=[{ancillary:{meal:[{mealName:'test',price:0}]}}]
    spyOn(component, 'editMeal').and.callThrough();
    component.editMeal();
    fixture.detectChanges();
    expect(component.editMeal).toHaveBeenCalled();
  });
});
