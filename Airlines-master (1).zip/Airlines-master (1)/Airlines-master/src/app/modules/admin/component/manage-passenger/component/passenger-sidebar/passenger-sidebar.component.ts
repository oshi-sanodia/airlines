import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-passenger-sidebar',
  templateUrl: './passenger-sidebar.component.html',
  styleUrls: ['./passenger-sidebar.component.scss']
})
export class PassengerSidebarComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
