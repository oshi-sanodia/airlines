import { ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ActivatedRoute } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { ManageFlightComponent } from './manage-flight.component';
import { CommonService } from 'src/app/shared/service/common.service';
import { of } from 'rxjs';
//import { CommonService } from '../../../../../../shared/service/common.service';

describe('ManageFlightComponent', () => {
  let component: ManageFlightComponent;
  let fixture: ComponentFixture<ManageFlightComponent>;
  let route: ActivatedRoute;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ManageFlightComponent ],
      imports: [HttpClientTestingModule, RouterTestingModule],
      providers: [CommonService]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ManageFlightComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call  applyFilter() method', () => {
    spyOn(component, 'applyFilter').and.callThrough();
    component.applyFilter();
    fixture.detectChanges();
    expect(component.applyFilter).toHaveBeenCalled();
  });

  
  // it('should call  getFlightDetails() method', () => {
  //   spyOn(component, 'getFlightDetails').and.callThrough();
  //   component.getFlightDetails();
  //   fixture.detectChanges();
  //   expect(component.getFlightDetails).toHaveBeenCalled();
  // });

  it('should call  getFlightDetails() method', () => {
    const mock=[{id:0}]
    spyOn(component, 'getFlightDetails').and.callThrough();
    spyOn(CommonService.prototype, 'getFlightDetails').and.returnValue(of(mock as any))
    component.getFlightDetails();
    fixture.detectChanges();
    expect(component.getFlightDetails).toHaveBeenCalled();
  });

});
