import { ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { AddFlightAncillaryComponent } from './add-flight-ancillary.component';
import { CommonService } from 'src/app/shared/service/common.service';
import { of } from 'rxjs';

describe('AddFlightAncillaryComponent', () => {
  let component: AddFlightAncillaryComponent;
  let fixture: ComponentFixture<AddFlightAncillaryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddFlightAncillaryComponent ],
      imports: [HttpClientTestingModule, RouterTestingModule],
      providers: [CommonService]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AddFlightAncillaryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should call  getFlightDetails() method', () => {
    const mock=[{id:0}]
    component.index=0
    component.flightDetails=[
      {ancillary: 
        {"services":[ 
          {
            id:1,
            service:"priority boarding"
          }
        ]
      }
    }
  ]
    spyOn(component, 'getFlightDetails').and.callThrough();
    spyOn(CommonService.prototype, 'getFlightDetails').and.returnValue(of(mock as any))
    component.getFlightDetails();
    fixture.detectChanges();
    expect(component.getFlightDetails).toHaveBeenCalled();
  });

  it('should call  getIndex() method', () => {
    const fId=0;
    spyOn(component, 'getIndex').and.callThrough();
    component.getIndex(fId);
    fixture.detectChanges();
    expect(component.getIndex).toHaveBeenCalled();
  });

  it('should call  addAncillaryService() method', () => {
    component.index=0
    component.flightDetails=[
      {ancillary: 
        {"services":[ 
          {
            id:1,
            service:"priority boarding"
          }
        ]
      }
    }
  ]
    component.flightAncillaryDetail=component.flightDetails[component.index].ancillary.services;
    spyOn(component, 'addAncillaryService').and.callThrough();
    component.addAncillaryService();
    fixture.detectChanges();
    expect(component.addAncillaryService).toHaveBeenCalled();
  });
});
