import { ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ActivatedRoute } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { ShoppingItemsComponent } from './shopping-items.component';
import { CommonService } from 'src/app/shared/service/common.service';
import { of } from 'rxjs';

describe('ShoppingItemsComponent', () => {
  let component: ShoppingItemsComponent;
  let fixture: ComponentFixture<ShoppingItemsComponent>;
  let route: ActivatedRoute;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ShoppingItemsComponent ],
      imports: [HttpClientTestingModule, RouterTestingModule],
      providers: [CommonService]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ShoppingItemsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call  getFlightDetails() method', () => {
    const mock=[{id:0}]
    spyOn(component, 'getFlightDetails').and.callThrough();
    //spyOn(CommonService.prototype, 'getFlightDetails').and.returnValue(of(mock as any))
    component.getFlightDetails();
    fixture.detectChanges();
    expect(component.getFlightDetails).toHaveBeenCalled();
  });
  
  it('should call  applyFilter() method', () => {
    component.index=0;
    component.flightDetails=[{shopItems:[
      {
        "id":1,
        "itemLink":"https://cdn4.ethoswatches.com/the-watch-guide/wp-content/uploads/2019/05/Ten-Best-Bronze-Watches-MM.jpg",
        "item":"watch",
        "price":6779
      }
    ]}]
    spyOn(component, 'applyFilter').and.callThrough();
    component.applyFilter();
    fixture.detectChanges();
    expect(component.applyFilter).toHaveBeenCalled();
  });

  it('should call  getIndex() method', () => {
    const fId=0;
    spyOn(component, 'getIndex').and.callThrough();
    component.getIndex(fId);
    fixture.detectChanges();
    expect(component.getIndex).toHaveBeenCalled();
  });

  it('should call  onDelete() method', () => {
    const index=0;
    component.index=0;
    component.flightDetails=[{shopItems:[
      {
        "id":1,
        "itemLink":"https://cdn4.ethoswatches.com/the-watch-guide/wp-content/uploads/2019/05/Ten-Best-Bronze-Watches-MM.jpg",
        "item":"watch",
        "price":6779
      }
    ]}]
    spyOn(component, 'onDelete').and.callThrough();
    component.onDelete(index);
    fixture.detectChanges();
    expect(component.onDelete).toHaveBeenCalled();
  });

});
