import { ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { EditShoppingItemsComponent } from './edit-shopping-items.component';
import { RouterTestingModule } from '@angular/router/testing';
import { CommonService } from 'src/app/shared/service/common.service';
import { of } from 'rxjs';

describe('EditShoppingItemsComponent', () => {
  let component: EditShoppingItemsComponent;
  let fixture: ComponentFixture<EditShoppingItemsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EditShoppingItemsComponent ],
      imports: [HttpClientTestingModule, RouterTestingModule],
      providers: [CommonService]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EditShoppingItemsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should call  getFlightDetails() method', () => {
    const mock=[{id:0}]
    spyOn(component, 'getFlightDetails').and.callThrough();
   // spyOn(CommonService.prototype, 'getFlightDetails').and.returnValue(of(mock as any))
    component.getFlightDetails();
    fixture.detectChanges();
    expect(component.getFlightDetails).toHaveBeenCalled();
  });

  it('should call  getPassengerDetails() method', () => {
    spyOn(component, 'getPassengerDetails').and.callThrough();
    component.getPassengerDetails();
    fixture.detectChanges();
    expect(component.getPassengerDetails).toHaveBeenCalled();
  });

  it('should call  updatePassengerDetail() method', () => {
    const id=0;
    spyOn(component, 'updatePassengerDetail').and.callThrough();
    component.updatePassengerDetail(id);
    fixture.detectChanges();
    expect(component.updatePassengerDetail).toHaveBeenCalled();
  });

  it('should call  onPreview() method', () => {
    spyOn(component, 'onPreview').and.callThrough();
    component.onPreview();
    fixture.detectChanges();
    expect(component.onPreview).toHaveBeenCalled();
  });

  it('should call  editItems() method', () => {
    component.index=0;
    component.itemIndex=0;
    component.flightDetails=[{shopItems:[{itemLink:"test",item:"test",price:"test"}]}]
    spyOn(component, 'editItems').and.callThrough();
    component.editItems();
    fixture.detectChanges();
    expect(component.editItems).toHaveBeenCalled();
  });
});
